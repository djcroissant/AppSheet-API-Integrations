var dataSet = JSON.parse(context.proxyResponse.content);
var output = dataSet.outputParameters.appsheet_output_object;

// convert object to a string and replace the HTTP response with new, formatted data
context.proxyResponse.content = JSON.stringify(output);